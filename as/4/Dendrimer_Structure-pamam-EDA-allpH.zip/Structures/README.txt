mnenomic: gXyz-eq.mol2
X - generation of the dendrimer
yz - denotes the structure belonging to different pH conditions.
     yz = np for high pH
        = p  for neutral pH
        = ac for low pH

Loading the structure in xleap.

source leaprc.gaff
a = loadmol2 gXyz-eq.mol2
edit a
 
