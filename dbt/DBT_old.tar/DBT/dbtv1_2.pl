

#This is dbtv1_2.pl. Manual type
#author: Vishal Maingi
#dated: 16.November.2011

use Tk;
my $number_core = "1";
my $number_frag = "1";
my $number_terminal = "1";
my $mw = new MainWindow;




#_______________________________________
##### last modified 8.2.2011#############|                       

print
"
                   #*##*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#
                   #                                            #
                   # * * *       ** *   T o o l k i t           #
                   # *     *     *    *       *                 #
                   # *      *    *    *       *                 #
                   # *       *   *   *        *                 #
                   # *       ||  *---*        *                 #
                   # *       *   *    *       *                 #
                   # *       r   *     *      *                 #
                   # *      e    *     *      *                 #  
                   # Dendrim     Builder      *                 #
                   #                                            #
                   # Tested on AMBER10 with AMBERTOOL1.2        #
                   #*##*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#

";

####################1# BUTTONS ################################### 

$l = $mw -> Button(-text=>"Dendrimer Builder Toolkit",-relief=>"sunken")-> grid();
$special = $mw -> Frame ();
$special -> grid();                       ######### using $special as frame here

#####################2#GUI, FRAME and WINDOWS MANAGEMENT ####################

#2.1# CORE 'aaa' residue
my $num_frm_core = $mw -> Frame ();
my $label_core = $num_frm_core -> Label (-text=>"Core Multiplicity");
my $rdb_core_1 = $num_frm_core -> Radiobutton(-text=>"1",-value=>"1",-variable=>\$number_core);
my $rdb_core_2 = $num_frm_core -> Radiobutton(-text=>"2",-value=>"2",-variable=>\$number_core);
my $rdb_core_3 = $num_frm_core -> Radiobutton(-text=>"3",-value=>"3",-variable=>\$number_core);
my $rdb_core_4 = $num_frm_core -> Radiobutton(-text=>"4",-value=>"4",-variable=>\$number_core);
my $rdb_core_5 = $num_frm_core -> Radiobutton(-text=>"5",-value=>"5",-variable=>\$number_core);
my $rdb_core_6 = $num_frm_core -> Radiobutton(-text=>"6",-value=>"6",-variable=>\$number_core);
#my $rdb_core_7 = $num_frm_core -> Radiobutton(-text=>"7",-value=>"7",-variable=>\$number_core); ### here one can modify if desired multiplicity
                                                                                                 ## for 'aaa' is more than 6, but please be careful

#2.2# FRAGMENT 'bbb' residue
#my $num_frm_frag = $mw -> Frame ();
my $label_frag = $num_frm_core -> Label(-text=>"Fragment Multiplicity: Prefered is 2 only");
my $rdb_frag_1 = $num_frm_core -> Radiobutton(-text=>"1",-value=>"1",-variable=>\$number_frag);
my $rdb_frag_2 = $num_frm_core -> Radiobutton(-text=>"2",-value=>"2",-variable=>\$number_frag);
my $rdb_frag_3 = $num_frm_core -> Radiobutton(-text=>"3",-value=>"3",-variable=>\$number_frag);
my $rdb_frag_4 = $num_frm_core -> Radiobutton(-text=>"4",-value=>"4",-variable=>\$number_frag);
my $rdb_frag_5 = $num_frm_core -> Radiobutton(-text=>"5",-value=>"5",-variable=>\$number_frag);
#my $rdb_frag_6 = $num_frm_core -> Radiobutton(-text=>"6",-value=>"6",-variable=>\$number_frag); ### here one can modify if desired multiplicity
                                                                                               ## for 'bbb' is more than 5, but please be careful  
#2.3#terminal
#my $num_frm_term = $mw -> Frame ();
my $label_term = $num_frm_core -> Label(-text=>"Terminal Multiplicity");
my $rdb_term_1 = $num_frm_core -> Radiobutton(-text=>"1",-value=>"1",-variable=>\$number_terminal);


###################3# TEXT BOX MANAGEMENT##################################

#3.1#core
#my $ent_c_frm = $mw -> Frame ();          ######### using $num_frm_core as frame only
my $ent_c1 = $num_frm_core -> Entry();
my $ent_c2 = $num_frm_core -> Entry();
my $ent_c3 = $num_frm_core -> Entry();
my $ent_c4 = $num_frm_core -> Entry();
my $ent_c5 = $num_frm_core -> Entry();
my $ent_c6 = $num_frm_core -> Entry();

#3.2#fragment
#my $ent_f_frm = $mw -> Frame ();      ######### using $num_frm_core as frame only
my $ent_f1 = $num_frm_core -> Entry();
my $ent_f2 = $num_frm_core -> Entry();
my $ent_f3 = $num_frm_core -> Entry();
my $ent_f4 = $num_frm_core -> Entry();
my $ent_f5 = $num_frm_core -> Entry();
my $ent_f6 = $num_frm_core -> Entry();

#3.3#terminal
#my $ent_t_frm = $mw -> Frame ();
my $ent_t = $num_frm_core -> Entry();

#3.4#Layers desired but initially was generation desired
my $gen_label = $special -> Label (-text => "Number of layers desired");
my $gen = $special -> Entry();
$gen_label -> grid(-row=>4,-column=>1);
$gen -> grid(-row=>4,-column=>2);

#3.5#files to be loaded
$files = $mw -> Frame ();

$ff = $files -> Label (-text=> "force field");
$ff_entry = $files -> Entry ();

$frcmod_a = $files -> Label (-text=> "frcmod file for 'aaa' or leave this option blank");
$frcmod_entry_a = $files -> Entry ();

$frcmod_b = $files -> Label (-text=> "frcmod file for 'bbb' or leave this option blank");
$frcmod_entry_b = $files -> Entry ();

$frcmod_c = $files -> Label (-text=> "frcmod file for 'ccc' or leave this option blank");
$frcmod_entry_c = $files -> Entry ();


$lib = $files -> Label (-text => "residues containing library name");
$lib_entry = $files -> Entry ();


#3.6# Step by step Minimisation

$min = $mw -> Frame ();

$filename = $min -> Label (-text => "Filename");
$filename_entry = $min -> Entry();

$mdin = $min -> Label (-text => "mdin");
$mdin_entry = $min -> Entry ();

$mdout = $min -> Label (-text => "mdout");
$mdout_entry = $min -> Entry();

$rst = $min -> Label (-text => "rst");
$rst_entry = $min -> Entry ();

$OK = $min -> Button (-text=>"OK",-command=> sub 
{
$f_e = $filename_entry -> get ();
$mi_e = $mdin_entry -> get ();
$mo_e = $mdout_entry -> get ();
$r_e = $rst_entry -> get ();

## these will simply print commands in text file that you ususally use in bash or csh terminal assuming $AMBERHOME environment has been set already
##it is very simple and main thing starts at heart of programme below
open OKMIN, ">ok_min"; 
print OKMIN "tleap -f $f_e\n","wait\n";
print OKMIN "sander -O -i $mi_e -o $mo_e -c dend.inpcrd -p dend.prmtop -r $r_e\n","wait\n";
print OKMIN "top2mol2 -at amber -p dend.prmtop -c $r_e -o USER.mol2\n","wait\n";
print OKMIN "perl -pi -e 's/aa......./aaa      /g' USER.mol2\n","wait\n","perl -pi -e 's/bb......./bbb      /g' USER.mol2\n","wait\n","perl -pi -e 's/cc......./ccc      /g' USER.mol2\n","wait\n","exit\n";
close OKMIN;


});

$sander = $min -> Button (-text=>"sander minimization",-command => sub 
{
system("chmod +x ok_min");
system("./ok_min");
print "File name $f_e JOB DONE"

});

$arrow = $min -> Label (-text => "---->> now press sander");


############  #4#GEOMETRY MANAGEMENT:  #########################
# May be there are shortcuts that can be used but this code was written as learning process ###
#4.1#core Radiobuttons

$label_core -> grid(-row=>1,-column=>1);
$num_frm_core -> grid(-row=>2,-columnspan=>1);
$rdb_core_1 -> grid(-row=>3,-column=>1);
$rdb_core_2 -> grid(-row=>4,-column=>1);
$rdb_core_3 -> grid(-row=>5,-column=>1);
$rdb_core_4 -> grid(-row=>6,-column=>1);
$rdb_core_5 -> grid(-row=>7,-column=>1);
$rdb_core_6 -> grid(-row=>8,-column=>1);

#4.2#core Entry
#$ent_c_frm -> grid (-row=>3,-column=>3); ######### using $num_frm_core as frame only
$ent_c1 -> grid (-row=>3,-column=>2);
$ent_c2 -> grid (-row=>4,-column=>2);
$ent_c3 -> grid (-row=>5,-column=>2);
$ent_c4 -> grid (-row=>6,-column=>2);
$ent_c5 -> grid (-row=>7,-column=>2);
$ent_c6 -> grid (-row=>8,-column=>2);

#4.3#fragment Radiobuttons
$label_frag -> grid(-row=>1,-column=>4);
#$num_frm_frag -> grid(-row=>3,-column=>4);  ######### using $num_frm_core as frame only
$rdb_frag_1 -> grid(-row=>3,-column=>4);
$rdb_frag_2 -> grid(-row=>4,-column=>4);
$rdb_frag_3 -> grid(-row=>5,-column=>4);
$rdb_frag_4 -> grid(-row=>6,-column=>4);
$rdb_frag_5 -> grid(-row=>7,-column=>4);
#$rdb_frag_6 -> grid(-row=>8,-column=>4);

#4.4#fragment Entry
#$ent_f_frm -> grid (-row=>3,-column=>7);      ######### using $num_frm_core as frame only
$ent_f1 -> grid (-row=>3,-column=>5);
$ent_f2 -> grid (-row=>4,-column=>5);
$ent_f3 -> grid (-row=>5,-column=>5);
$ent_f4 -> grid (-row=>6,-column=>5);
$ent_f5 -> grid (-row=>7,-column=>5);
$ent_f6 -> grid (-row=>8,-column=>5); #4.5#terminal Radiobuttons
$label_term -> grid(-row=>1,-column=>7);
#$num_frm_term -> grid(-row=>3,-column=>10);
$rdb_term_1 -> grid(-row=>3,-column=>7);

#4.6#terminal Entry
#$ent_t_frm -> grid (-row=>3,-column=>11);
$ent_t -> grid (-row=>3,-column=>8);


#4.7#files to be loaded
$files -> grid ();

$ff -> grid (-row=>1,-column=>1);
$ff_entry -> grid (-row=>1,-column=>2);

$frcmod_a -> grid (-row=>2,-column=>1);
$frcmod_entry_a -> grid (-row=>2,-column=>2);

$frcmod_b -> grid (-row=>3,-column=>1);
$frcmod_entry_b -> grid (-row=>3,-column=>2);

$frcmod_c -> grid (-row=>4,-column=>1);
$frcmod_entry_c -> grid (-row=>4,-column=>2);


$lib -> grid (-row=>6,-column=>1);
$lib_entry -> grid (-row=>6,-column=>2);


#4.8#Step by step Minimisation
$min -> grid ();

$filename -> grid (-row=>1,-column=>1);
$filename_entry -> grid (-row=>1,-column=>2);

$mdin -> grid (-row=>2,-column=>1);
$mdin_entry -> grid (-row=>2,-column=>2);

$mdout -> grid (-row=>3,-column=>1);
$mdout_entry -> grid (-row=>3,-column=>2);

$rst -> grid (-row=>4,-column=>1);
$rst_entry -> grid (-row=>4,-column=>2);

$OK -> grid (-row=>5,-column=>3);

$arrow -> grid (-row=>5,-column=>4);

$sander -> grid (-row=>5,-column=>5);



#                            
#######this is heart of programme builder #############################
#                                                       

my $but = $mw -> Button(-text=>"go", -command =>sub {

my $a_c1 = $ent_c1 -> get ();    # get all the values provided by user in boxes
my $a_c2 = $ent_c2 -> get ();    
my $a_c3 = $ent_c3 -> get ();
my $a_c4 = $ent_c4 -> get ();
my $a_c5 = $ent_c5 -> get ();
my $a_c6 = $ent_c6 -> get ();
my @a_c = ($a_c1,$a_c2,$a_c3,$a_c4,$a_c5,$a_c6);

my $a_f1 = $ent_f1 -> get ();    # get all the values provided by user in boxes
my $a_f2 = $ent_f2 -> get ();
my $a_f3 = $ent_f3 -> get ();
my $a_f4 = $ent_f4 -> get ();
my $a_f5 = $ent_f5 -> get ();
my $a_f6 = $ent_f6 -> get ();
my $a_f1 = $ent_f1 -> get ();
my @a_f = ($a_f1,$a_f2,$a_f3,$a_f4,$a_f5,$a_f6);

my $a_t = $ent_t -> get ();

my $a_g = $gen -> get ();

$ff_e = $ff_entry -> get ();
$f_e_a = $frcmod_entry_a -> get ();
$f_e_b = $frcmod_entry_b -> get ();
$f_e_c = $frcmod_entry_c -> get ();
$l_e = $lib_entry -> get ();


my $g = $a_g;
my $cm = $number_core; # cm is core multiplicity #
my $i = 2;
my $fm = $number_frag; # fm is fragment multiplicity PREFERRED TO BE "2" only 


## First layer of 'bbb' residues ## 
open INIT, ">dbt1" ;
print INIT "source leaprc.$ff_e\n","loadamberparams $f_e_a\n","loadamberparams $f_e_b\n","
loadamberparams $f_e_c\n","loadoff $l_e\n";
print INIT "set bbb head bbb.1.$a_f[$number_frag]\n"; 
print INIT "set ccc head ccc.1.$a_t\n";

my $x =0;
for (1..$cm)
{
print INIT "set aaa tail aaa.1.$a_c[$x]\n","aaa = sequence {aaa bbb}\n";
$x++;
}
print INIT "saveamberparm aaa dend.prmtop dend.inpcrd\n","quit\n";
close INIT;

# remaining layers of 'bbb' residue

$o = 2;
$a = 2;
for (1..$a_g-1)
{
 open GENRTNS, ">dbt$o";
 print GENRTNS "source leaprc.$ff_e\n","loadamberparams $f_e_a\n","loadamberparams $f_e_b\n","loadamberparams $f_e_c\n","loadoff $l_e\n","aaa = loadmol2 USER.mol2\n","set bbb head bbb.1.$a_f[$number_frag]\n","set ccc head ccc.1.$a_t\n"; 
 for (1..$cm)
 {
  $y = 0;
  for (1..$fm)
    {
      print GENRTNS "set aaa tail aaa.$a.$a_f[$y]\n","aaa = sequence {aaa bbb}\n";
      $y++;
    }
  $a++;
 }
$cm = $cm*$fm;
$o++;
print GENRTNS "saveamberparm aaa dend.prmtop dend.inpcrd\n","quit\n";
close GENRTNS;
}

# terminal 'ccc' layer

open TERM, ">dbt_term";
print TERM "source leaprc.$ff_e\n","loadamberparams $f_e_a\n","loadamberparams $f_e_b\n","loadamberparams $f_e_c\n","loadoff $l_e\n","aaa = loadmol2 USER.mol2\n","set bbb head bbb.1.$a_f[$number_frag]\n","set ccc head ccc.1.$a_t\n";
for (1..$cm)
 {
 $z = 0;
  for (1..$fm)
  {
   print TERM "set aaa tail aaa.$a.$a_f[$z]\n","aaa = sequence {aaa ccc}\n";
   $z++;
  }
 $a++;
 }
print TERM "saveamberparm aaa dend.prmtop dend.inpcrd\n","quit\n";
close TERM;

}) -> grid();


### quit and close

$quit = $mw -> Button(-text=>"quit", -command =>sub 
{
$bye = new MainWindow;
$authors = $bye -> Label(-text => "\n Please refer: GAFF for dendrimer modeling\n\n Maingi V., Jain V., Bharatam P. V., Maiti P. K.\n\n Mail your Compliments, Suggestions, Errors or Querries at dbt.query\@gmail.com") -> grid();
$ok = $bye -> Button(-text=>"OK", -command =>sub {exit}) -> grid();
}) -> grid ();
MainLoop;
