
Thanks for Downloading!

This is Dendrimer Builder Toolkit (DBT)

You have downloaded Dendrimer Builder Toolkit (DBT) from: http://www.physics.iisc.ernet.in/~maiti/

******************************************************************
Please feel free to contact for any suggestions, queries:        *
                                                                 *
Prof. Prabal K. Maiti                                            *
Department of Physics,Indian Institute of Science                *
Bangalore-560012,India                                           *
                                                                 *
E-mail: maiti aT physics.iisc.ernet.in                           *
                                                                 *
                 and                                             *
                                                                 *
please 'cc' mail to dbt.query aT gmail.com (replace aT with @)   *
******************************************************************

This README.txt is one of the files you extracted from DBT.tar

The directory where DBT.tar was extracted, you should be able to see the following: (also this README.txt itself :-)

#1# dbtv2.pl (new modified and auto DBT)

#2# dbtv1_2.pl (older version, to be used only for special cases)

#3# How_to_use_Dendrimer_Builder_Toolkit.pdf (Tutorial for DBT usage, please visit-
 -website for latest modifications if any)

#4# min.in (this is AMBER input file; you can modify this accordingly)

#5# pnp.lib ('aaa','bbb','ccc' residues for PAMAM dendrimer; note in this library 'ccc' is protonated)

## ppi.lib ('aaa','bbb','ccc' residues for PPI dendrimer, non-protonated only)





