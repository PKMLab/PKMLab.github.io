## DBT libraries


1)*****
PAMAM-EDA (ethylene-diamine)
AVAILABLE

pamam_basic_EDA.lib => EDA-PAMAM basic pH residues
pamam_neutral_EDA.lib => EDA-PAMAM neutral pH residues


2)*****
PPI-DAB (diamino-butyl)
AVAILABLE

ppi_acid_DAB.lib => DAB-core-PPI acid pH, so all Nitrogens protonated
ppi_neutral_DAB.lib => DAB-core-PPI neutral pH, alternate layers are protonated(NOTE: this is named as ppi‐neu.lib)
ppi_basic_DAB.lib => DAB-core-PPI basic pH residues


please mail: dbt.query@gmail.com for comments, suggestions or any reports.
We will be happy to help you for new residues for building polymers/dendrimers.

Vishal Maingi
PKM group, IISc.
Bangalore, INDIA

