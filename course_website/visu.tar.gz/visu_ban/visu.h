/* Function declarations. */

void allocate_memory_visu(int n_atoms, int n_mols, int n_species,
   int period_switch, double ***scaled_atom_coords, int **atom_rel,
   int **atom_mol, double **atom_mass, int **atom_type, double ***mol_coords,
   double ***scaled_mol_coords, double ***rel_atom_coords,
   double ***h_inv);

