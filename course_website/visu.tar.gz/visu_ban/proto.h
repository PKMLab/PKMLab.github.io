/* Function declarations */

void read_mass_params(char *mass_file, mass_entry **mass, int *n_mass);
void read_lj_params(char *lj_file, lj_entry **lj, int *n_lj);
void read_e6_params(char *e6_file, e6_entry **e6, int *n_e6);
void read_set_up_pot(char *pot_file, int vdw_switch, int vdw_rad_switch,
     type_entry *atm_type, int n_type, int ***comb_pot, double ****comb_par);
void select_pot(int id_0, int id_1, int pot_form, char **token, int n_tokens,
     int vdw_rad_switch, int comb_flag, double ***comb_par);
void read_config_direct(char *config_file, int period_switch, double ***h, 
    int n_atoms, double ***atom_coords);
void set_up_force_field(int n_species, int n_mols, int *n_atoms_per_mol,
     int n_mass, mass_entry *mass, int *mol_species, int *n_bonds_per_mol,
     double ***temp_atm_mass, char ***temp_atm_type, double **mol_mass, 
     double **mol_mass_true, int **mol_first_atm);
void combination_array(int vdw_switch, int vdw_rad_switch, int n_species,
     int *n_atoms_per_mol, int n_lj, lj_entry *lj, int n_pot, pot_entry *pot,
     char ***temp_atm_type, double **temp_atm_sigma, double **temp_atm_eps,
     double **temp_atm_chg, double *****comb_sigma, double *****comb_sigma2,
     double *****comb_r_min2, double *****comb_eps, double *****comb_four_eps,
     int *****comb_pot, double *****comb_chg, double *r_on, double *r_off);

void allocate_memory_simu(int n_atoms, int n_mols, int n_species,
int n_blocks,
int period_switch, double ***scaled_atom_coords, int **atom_rel,
int **atom_mol, double **atom_mass, int **atom_type, double ***mol_coords,
double ***scaled_mol_coords, double ***rel_atom_coords,
double ***h_inv, atom_cell **atom_cells, int **offsets,
int **offsets_total, int noffsets, nl_entry ***nl_head,
nl_entry ***nl_tail, double ***atom_move, int *n_atoms_per_mol, 
int ****exclusions,
double ***old, double ***s_old, double ***rel_old, double ***mol_old,
double ***ds_opt, double ***mol_inert_mt, double ****mol_inert_axis,
double ****mol_order_inst, double ***lambda, double ****v, double **phi,
double **cos_theta, double ***h_block, double **h_ave, double **h_unc,
double **layer_spacing_block, double *****mol_order_block,
double ****mol_order_ave, double ****mol_order_unc,
double ****lambda_block, double ***lambda_ave, double ***lambda_unc,
double ***cos_theta_block, double **cos_theta_ave, double **cos_theta_unc,
double ***phi_block, double **phi_ave, double **phi_unc,
  double ****mol_stress_block, double ***mol_stress_ave,
  double ***mol_stress_unc, double **press_block, double **vol_block,
  double **rho_block, double **pe_vdw_s_block, double **n_mol_moves_block,
double **n_mol_accept_block, double **n_reshape_moves_block,
double **n_reshape_accept_block,
int **offsets_x, int **offsets_y, int **offsets_z,
double ***vdw_s, double ***vdw_s_single, double ***at_stress_vdw_s,
double ***at_stress_vdw_single, double ***mol_stress_vdw_s,
double ***mol_stress_vdw_single, double ***mol_range);

void relative_atoms(int n_mols, int *mol_species, int *mol_first_atm,
   int *n_atoms_per_mol, double **temp_atm_mass, int **temp_atm_type_i,
   int *atom_rel, int *atom_mol, double *atom_mass, int *atom_type);

void exclusion_array(int n_species, int *n_atoms_per_mol, int *excl_switch,   
       int **temp_atm_nbr, int ***temp_atm_br, int ****exclusions);

void set_up_scan_list(int n_species, int *n_atoms_per_mol, int **temp_atm_nbr,
   int ***temp_atm_br, int ***scan_atm_1, int ***scan_atm_2);
void adjust_template_molecules(int n_species, int *n_atoms_per_mol,
      int *principal, double **temp_atm_mass, double ***temp_atm_pos);
void scaled_atomic_coords_single(int i_mol, int *n_atoms_per_mol,
       int *mol_first_atm, int *mol_species, double **h_inv, 
       double **atom_coords, double **scaled_atom_coords);
void box_dimensions(double **h, double **h_inv, int period_switch, double r_off,  double mol_max_length);
void box_inverse(double **h, double **h_inv);
void center_of_mass_positions(int period_switch, int n_mols, int n_species, 
  int *n_atoms_per_mol, int *mol_species, double *atom_mass, 
  int *mol_first_atm, double **atom_coords, double **scaled_atom_coords, 
  int **scan_atm_1, int **scan_atm_2, double *mol_mass, double **h, 
  double **h_inv, double **mol_coords, double **scaled_mol_coords, 
  double **rel_atom_coords);
int isotropic_start(int n_mols, long *i_ran, int *mol_first_atm,
      int *n_atoms_per_mol, int *mol_species, int *atom_rel,
      double ***temp_atm_pos, double **h, double **h_inv,
      double **mol_coords, double **scaled_mol_coords,
      double **atom_coords, double **scaled_atom_coords,
      double ****combine, int *n_bonds_per_mol, 
      int **temp_bonds_1, int **temp_bonds_2);
int nematic_start(int n_mols, long *i_ran, int *mol_first_atm,
      int *n_atoms_per_mol, int *mol_species, int *atom_rel,
      double ***temp_atm_pos, double **h, double **h_inv,
      double **mol_coords, double **scaled_mol_coords,
      double **atom_coords, double **scaled_atom_coords,
      double ****combine, int *n_bonds_per_mol, 
      int **temp_bonds_1, int **temp_bonds_2);
int smectic_start(int n_mols, int n_species, long *i_ran, int n_layers,
      int *n_mols_per_species, int *mol_first_atm,
      int *n_atoms_per_mol, int *mol_species, int *atom_rel,
      double ***temp_atm_pos, double **h, double **h_inv,
      double **mol_coords, double **scaled_mol_coords,
      double **atom_coords, double **scaled_atom_coords,
      double ****combine, int *n_bonds_per_mol,
      int **temp_bonds_1, int **temp_bonds_2);
int overlaps(int i_mol, int j_mol, int *mol_first_atm,
      int *n_atoms_per_mol, int *mol_species, int *atom_rel,
      double **h, double **scaled_atom_coords, double ****combine);
void write_header_direct(char *header_file, int period_switch, int n_species,
  int *n_atoms_per_mol, int **temp_atm_lab, char ***temp_atm_type,
  int **temp_atm_nbr, int ***temp_atm_br, double ***temp_atm_ord,
  double ***temp_atm_pos, double **temp_atm_chg, 
  int *n_bonds_per_mol, int **temp_bonds_1,
  int **temp_bonds_2, double **temp_bonds_ord, int *n_mols_per_species,
  int n_mols, int *mol_species);
void mc_cycle(int n_mols, int n_atoms, int vdw_switch, int period_switch,
      long *i_ran, int *mol_first_atm, int *n_atoms_per_mol, int *mol_species,
      int *atom_rel, int *atom_mol, int *atom_type, double ***temp_atm_pos,
      double **h, double **h_inv, double aspect_xy, double aspect_xz,
      double **mol_coords, double **scaled_mol_coords, double **atom_coords,
      double **scaled_atom_coords, double **rel_atom_coords, int ***exclusions,
      int **comb_pot, double ***comb_par, double gamma,
      double three_gamma_over_two, double two_over_gamma_cubed, double dr_max,
      double *ds_mol_max, double dang_mol_max, double dh_max, int reshape_axis,
      double mol_max_length, double r2_on,
      double r2_off, double r_off, double r_nl, double r2_nl, double **s_old,
      double **old, double **rel_old, double **mol_old, int press_switch,
      double reduce_boltz, double press, int neigh_switch,
      int phant_switch, int **first, int **last,
      phantom_cell **phantoms, int noffsets, int *nc, int *nc_p,
      int *nc_p_total, int kc, int *phantom_skip, atom_cell *atom_cells,
      int *offsets, nl_entry **nl_head, nl_entry **nl_tail, double **atom_move,
      int n_reshape, double *pe_vdw_s, int *n_mol_moves,
      int *n_mol_accept, int *n_reshape_moves, int *n_reshape_accept,
      double **ds_opt,
      double **at_stress_vdw_s, double **mol_stress_vdw_s, double **vdw_s,
      int *offsets_x, int *offsets_y, int *offsets_z);

int mol_move(int period_switch, int vdw_switch, int i_mol, int n_mols,
      int n_atoms, long *i_ran, int *mol_first_atm, int *n_atoms_per_mol,
      int *mol_species, int *atom_rel, int *atom_mol, int *atom_type,
      double ***temp_atm_pos, double **h, double **h_inv, double **mol_coords,
      double **scaled_mol_coords, double **atom_coords,
      double **scaled_atom_coords, double **rel_atom_coords,
      int ***exclusions, int **comb_pot, double ***comb_par, double gamma,
      double three_gamma_over_two,
      double two_over_gamma_cubed, double *ds_mol_max, double dang_mol_max,
      double r2_on, double r_off, double r2_off, double r_nl, double r2_nl,
      double **s_old, double **old, double **rel_old, double reduce_boltz,
      int neigh_switch,
      int phant_switch, int *first, int *last, phantom_cell *phantoms,
      int noffsets, int *nc, int *nc_p, int kc, int *phantom_skip,
      atom_cell *atom_cells, int *offsets, nl_entry **nl_head,
      nl_entry **nl_tail, double **atom_move,
      double *pe_vdw_s, double **ds_opt, int *offsets_x, int *offsets_y,
      int *offsets_z);

int reshape_move(int period_switch, int vdw_switch, int reshape_axis,
      double mol_max_length, int n_mols, int n_atoms,
      long *i_ran, int *mol_first_atm, int *n_atoms_per_mol, int *mol_species,
      int *atom_rel, int *atom_mol, int *atom_type, double **h, double **h_inv,
      double **mol_coords, double **scaled_mol_coords, double **atom_coords,
      double **scaled_atom_coords, double **rel_atom_coords, int ***exclusions,
      int **comb_pot, double ***comb_par, double gamma,
      double three_gamma_over_two, double two_over_gamma_cubed, double dh_max,
      double dr_max, double *ds_mol_max, double r2_on, double r2_off,
      double r_off, double r2_nl, double r_nl, double **mol_old,
      double reduce_boltz,
      int neigh_switch, int phant_switch, int **first, int **last,
      phantom_cell **phantoms, int noffsets, int *nc, int *nc_p,
      int *nc_p_total, int kc, int *phantom_skip, atom_cell *atom_cells,
      int *offsets, nl_entry **nl_head, nl_entry **nl_tail, double **atom_move,
      double *pe_vdw, double **at_stress_vdw_s, double **mol_stress_vdw_s,
      double **vdw_s, int *offsets_x, int *offsets_y, int *offsets_z);

int reshape_move_press(int period_switch, int vdw_switch, int reshape_axis,
      double mol_max_length, int n_mols, int n_atoms, long *i_ran,
      int *mol_first_atm, int *n_atoms_per_mol, int *mol_species,
      int *atom_rel, int *atom_mol, int *atom_type, double **h, double **h_inv,
      double aspect_xy, double aspect_xz, double **mol_coords,
      double **scaled_mol_coords, double **atom_coords,
      double **scaled_atom_coords, double **rel_atom_coords, int ***exclusions,
      int **comb_pot, double ***comb_par, double gamma,
      double three_gamma_over_two, double two_over_gamma_cubed, double dh_max,
      double dr_max, double *ds_mol_max, double r2_on, double r2_off,
      double r_off, double r2_nl, double r_nl, double **mol_old,
      double reduce_boltz, double press, int neigh_switch, int phant_switch,
      int **first, int **last, phantom_cell **phantoms, int noffsets,
      int *nc, int *nc_p, int *nc_p_total, int kc, int *phantom_skip,
      atom_cell *atom_cells, int *offsets, nl_entry **nl_head,
      nl_entry **nl_tail, double **atom_move, double *pe_vdw,
      double **at_stress_vdw_s, double **mol_stress_vdw_s, double **vdw_s,
      int *offsets_x, int *offsets_y, int *offsets_z);


void lj_s_period(int *mol_species, int *atom_rel, int *atom_mol,
   int *atom_type, int n_atoms,
   int *n_atoms_per_mol, int ***exclusions, int **comb_pot,
   double ***comb_par, double **h, double r2_on, double r2_off,
   double **scaled_atom_coords, double **scaled_mol_coords,
   double **rel_atom_coords, double gamma, double three_gamma_over_two,
   double two_over_gamma_cubed, double *pe_vdw_s, double **f_vdw_s,
   double **mol_stress_vdw_s);

void lj_s_period_single(int skip, int mol, int *mol_species, int *atom_rel,
   int *atom_mol, int *atom_type, int n_atoms, int *n_atoms_per_mol,
   int ***exclusions, int **comb_pot, double ***comb_par, double **h,
   double r2_on, double r2_off, double **scaled_atom_coords, double gamma,
   double three_gamma_over_two, double two_over_gamma_cubed,
   double *pe_vdw_s_single);

void optimize_molecule_moves(int n_mols, double **h, double *dr_max,
  double *dr_max_old, double *ds_mol_max, double *dang_mol_max,
  double ratio_dang_dr, double *opt_time, double *efficiency, double **ds_opt);
void optimize_reshape_moves(double **h, double reshape_accept_rate,
   double *dh_max);
double compute_efficiency(int n_mols, double **h, double *opt_time,
   double **ds_opt);
double cpu(void);

void set_up_cells_phantom(double **h, int *nc, int *nc_p, int *nc_p_total,
    atom_cell *atom_cells, int kc, int period_switch, double r_nl,
    double r_off, int neighb_switch, int **first, int **last, int *offsets,
    int n_atoms, double **scaled_atom_coords, double **atom_coords, 
    phantom_cell **phantoms, int *phantom_skip);

void set_up_offsets(int kc, int *nc_p, int *offsets);

void set_up_phantom_arrays(int cell_flag_1, int *nc_p, int nc_p_total,
    phantom_cell **phantoms, int kc, int *nc, double **h);

void phantom_block(int rx, int ry, int rz, int *nc, int *nc_p, int kc,
   double **h, phantom_cell *phantoms);

void initialize_cells(int n_atoms, int period_switch, double **h,
    double **atom_coords, double **scaled_atom_coords, int *first, int *last,
    int *nc, int *nc_p, int nc_p_total, int kc, atom_cell *atom_cells,
    phantom_cell *phantoms, int *phantom_skip);

int cell_index_period(double *scaled_coords, int *nc, int *nc_p, int kc);


void add_entry(int i, int ic, atom_cell *atom_cells, int *first, int *last);

void remove_entry(int i, int ic, atom_cell *atom_cells, int *first, int *last);

void update_phantoms(int n_atoms, atom_cell *atom_cells, int *phantom_skip,
                     phantom_cell *phantoms, double **atom_coords);

void update_cells_single(int i_mol, int period_switch, int n_atoms, double **h,
    double **scaled_atom_coords, double **atom_coords, atom_cell *atom_cells,
    int *first, int *last, phantom_cell *phantoms, int kc, int *phantom_skip,
    int *nc, int *nc_p, int *n_atoms_per_mol, int *mol_species,
    int *mol_first_atm);

void update_phantoms_single(int i_mol, int n_atoms, atom_cell *atom_cells,
    int *phantom_skip, phantom_cell *phantoms, double **atom_coords,
    int *mol_first_atm, int *mol_species, int *n_atoms_per_mol);

/*************************************************************************/
/* for no Phantom case decalre all the subroutine */

void set_up_cells_nophantom(double **h, int *nc, int *nc_p, int *nc_p_total,
                  atom_cell *atom_cells, int kc, int period_switch,
                  double r_nl, double r_off, int neigh_switch,
                  int **first, int **last,
                  int *offsets_x, int *offsets_y, int *offsets_z, int n_atoms,
                  double **scaled_atom_coords, double **atom_coords);

void set_up_offsets_nophantom(int kc, int *nc_p, int *offsets_x, int *offsets_y, int *offsets_z);

void initialize_cells_nophantom(int n_atoms, int period_switch, double **h,
                      double **scaled_atom_coords, double **atom_coords,
                      int *first, int *last, int nc_p_total, int *nc_p,
                      atom_cell *atom_cells, int kc, int *nc);

void update_cells_nophantom(int period_switch, int n_atoms, double **h,
                  double **scaled_atom_coords, double **atom_coords,
                  atom_cell *atom_cells, int *first, int *last,
                  int kc, int *nc, int *nc_p);

void update_cells_single_nophantom(int i_mol, int period_switch, int n_atoms, double **h,
                  double **scaled_atom_coords, double **atom_coords,
                  atom_cell *atom_cells, int *first, int *last,
                  int kc, int *nc,
                  int *nc_p, int *n_atoms_per_mol, int *mol_species,
                  int *mol_first_atm);
int cell_index_period_nophantom(double *scaled_coords, int *nc, int *nc_p, int kc);



void neighbor_lists_period(int *mol_species, int *atom_rel, int *atom_mol,
   int n_atoms, int *n_atoms_per_mol, int ***exclusions, double **h,
   double r2_on, double r2_off, double **scaled_atom_coords, int period_switch,
   int *first, int *last, phantom_cell *phantoms, int noffsets, int *nc_p,
   int kc, int *phantom_skip, int *nc, atom_cell *atom_cells, int *offsets,
   double **atom_coords, double **atom_move, nl_entry **nl_head,
   nl_entry **nl_tail, double r2_nl);

void neighbor_lists_period_single(int mol, int *mol_species, int *atom_rel,
   int *atom_mol, int *mol_first_atm,
   int n_atoms, int *n_atoms_per_mol, int ***exclusions, double **h,
   double r2_on, double r2_off, double **scaled_atom_coords, int period_switch,
   int *first, int *last, phantom_cell *phantoms, int noffsets, int *nc_p,
   int kc, int *phantom_skip, int *nc, atom_cell *atom_cells, int *offsets,
   double **atom_coords, double **atom_move, nl_entry **nl_head,
   nl_entry **nl_tail, double r2_nl);

void zero_move(int n_atoms, double **atom_move);


