# define ERROR 1
# define SUCCESS 0


/* WARNING : THESE DECLARATIONS ARE ONLY FOR 64bit PROCESSORS */
struct template_bmpheader
{
	char bftype[2];
	int bfsize;   
	short int reserved[2];                 
	int headersize;
};

struct template_bmpfile
{	
	int bmpsize;
	int bmpwidth;
	int bmpheight;
	short int biplanes;
	short int bitcount;
	int bicompression;
	int bisizeimage;
	int bixpelspermeter;
	int biypelspermeter;
	int biclrused;
	int biclrimportant;
};