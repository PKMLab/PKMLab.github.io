/* Function declaration for cluster counting */
void allocate_memory_pair(int n_atoms, int n_mols, int n_species,
     int period_switch, double ***scaled_atom_coords, int **atom_rel,
     int **atom_mol, double **atom_mass, int **atom_type,
     double ***mol_coords,
     double ***scaled_mol_coords, double ***rel_atom_coords,
     double ***h_inv, atom_cell **atom_cells, int **offsets,
     int **offsets_total, int noffsets, nl_entry ***nl_head,
     nl_entry ***nl_tail, double ***atom_move, int *n_atoms_per_mol,
     int ****exclusions, int **inClust, int **clustSize, int **clustHead,
     int **clustNext, int **hist, double ***histRdf, double **tRdf,
     int sizeHistRdf);

void relative_atoms_pair(int n_mols, int *mol_species, int *mol_first_atm,
   int *n_atoms_per_mol, double **temp_atm_mass, int **temp_atm_type_i,
   int *atom_rel, int *atom_mol, double *atom_mass, int *atom_type);
