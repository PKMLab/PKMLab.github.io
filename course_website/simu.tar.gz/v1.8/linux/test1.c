#include <stdio.h>
#include <stdlib.h>
#include <math.h>

main()
{
int i, j;
double x;

i = 7;
j = 8;

x = (double) i / j;
printf("x = %g\n", x);
}
