/* Input/output routines for template module. */

#include "build.h"
#include "ff.h"

/****************************************************************************/
/* Read molecular structure from structure file. */
/*
input : 
    array of files containing molecular structure of each specie (struct_file)

output :
    array of number of atoms per molecule for each specie (n_atoms_per_mol)
    array of template atom labels (temp_atm_lab)
    array of template atom type (temp_atm_type)
    array of template atom position (temp_atm_pos)
    array of template atom charge (temp_atm_chg)
    array of template atom numbre of branching (temp_atm_nbr)
    array of template atom label of branched atoms (temp_atm_br)
    array of template atom label order (temp_atm_ord)
    array of the number of bonds per molecule for each specie (n_bonds_per_mol)
    arrays of template bond - the labels of the 2 atoms sharing a bond
                                                  (temp_bonds_1, temp_bonds_2) 
    array of template bond - the order of a template bond (temp_bonds_ord)
*/

void read_str(char *struct_file, int *n_atoms_per_mol, int **temp_atm_lab,
   char ***temp_atm_type, double ***temp_atm_pos, double **temp_atm_chg,
   int **temp_atm_nbr, int ***temp_atm_br, double ***temp_atm_ord,
   int *n_bonds_per_mol, int **temp_bonds_1, int **temp_bonds_2,
   double **temp_bonds_ord)
{
   FILE *f_input;
   char line[MAX_LINE];
   int i, atom_1, atom_2, order;

   /* Open structure file. */
   if ((f_input = fopen(struct_file, "r")) == NULL)
      error_exit("Unable to open structure file in read_str");

   /* Skip comments in header of structure file. */
   do {
      if (fgets(line, MAX_LINE, f_input) == NULL)
         error_exit("Molecular structure data missing in read_str");
   } while (line[0] == '#');

   /* Read in number of atoms per molecule. */
   sscanf(line, "%d", n_atoms_per_mol);

   /* Allocate memory for array of template atom attributes. */
   *temp_atm_lab = allocate_1d_array(*n_atoms_per_mol, sizeof(int));
   *temp_atm_type = allocate_2d_array(*n_atoms_per_mol, TYPE_MAX, sizeof(char));
   *temp_atm_pos = allocate_2d_array(*n_atoms_per_mol, NDIM, sizeof(double));
   *temp_atm_chg = allocate_1d_array(*n_atoms_per_mol, sizeof(double));
   *temp_atm_nbr = allocate_1d_array(*n_atoms_per_mol, sizeof(int));
   *temp_atm_br = allocate_2d_array(*n_atoms_per_mol, 6, sizeof(int));
   *temp_atm_ord = allocate_2d_array(*n_atoms_per_mol, 6, sizeof(double));

   for (i = 0; i < *n_atoms_per_mol; ++i)
      {
      fscanf(f_input, "%d %s %lf %lf %lf %lf",
         &(*temp_atm_lab)[i], (*temp_atm_type)[i], &(*temp_atm_pos)[i][0],
         &(*temp_atm_pos)[i][1], &(*temp_atm_pos)[i][2], &(*temp_atm_chg)[i]);
      }
   /* Read in number of bonds per molecule. */
   fscanf(f_input, "%d", n_bonds_per_mol);

   /* Allocate memory for array of template bond attributes. */
   *temp_bonds_1 = allocate_1d_array(*n_bonds_per_mol, sizeof(int));
   *temp_bonds_2 = allocate_1d_array(*n_bonds_per_mol, sizeof(int));
   *temp_bonds_ord = allocate_1d_array(*n_bonds_per_mol, sizeof(double));

   /* Read in template bond attributes. */
   for (i = 0; i < *n_bonds_per_mol; ++i)
      {
      fscanf(f_input, "%d %d %lf",
         &(*temp_bonds_1)[i], &(*temp_bonds_2)[i], &(*temp_bonds_ord)[i]);
      }

   /* Close structure file. */
   fclose(f_input);

   /* Add connectivity information to template atom array. */
   for (i = 0; i < *n_atoms_per_mol; ++i)
      (*temp_atm_nbr)[i] = 0;
   for (i = 0; i < *n_bonds_per_mol; ++i) {
      atom_1 = (*temp_bonds_1)[i];
      atom_2 = (*temp_bonds_2)[i];
      order = (*temp_bonds_ord)[i];
      (*temp_atm_br)[atom_1][(*temp_atm_nbr)[atom_1]] = atom_2;
      (*temp_atm_br)[atom_2][(*temp_atm_nbr)[atom_2]] = atom_1;
      (*temp_atm_ord)[atom_1][(*temp_atm_nbr)[atom_1]] = order;
      (*temp_atm_ord)[atom_2][(*temp_atm_nbr)[atom_2]] = order;
      ++(*temp_atm_nbr)[atom_1];
      ++(*temp_atm_nbr)[atom_2];
   }
}

/****************************************************************************/
/* Read mass parameters from specified data file. */
/*input :  
      force field file name (mass_file)

output : 
      the FF mass structure (mass)
      the number of entries in FF mass structure (n_mass)
*/

void read_mass_params(char *mass_file, mass_entry **mass, int *n_mass)
{
   FILE *f_input;
   char line[MAX_LINE];
   mass_entry tmp_mass;

   /* Open parameter file. */
   if ((f_input = fopen(mass_file, "r")) == NULL)
      error_exit("Unable to open parameter file in read_mass_params");

   /* Read in mass entries. */
   while (fgets(line, MAX_LINE, f_input) != NULL) {
      sscanf(line, "%s %lf %lf",
         tmp_mass.type, &tmp_mass.true_mass, &tmp_mass.eff_mass);
      if (((*mass) = realloc((*mass), 
        ((*n_mass) + 1) * sizeof(mass_entry))) == NULL)
         error_exit("Out of memory in read_mass_params");
      (*mass)[(*n_mass)] = tmp_mass;
      ++(*n_mass);
   }
 
   /* Close input file. */
   fclose(f_input);
}

