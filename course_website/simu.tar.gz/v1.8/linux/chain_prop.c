  EvalChainProps () {
    real c[4], g[7], gVal[4], shift[4], sumR[4], sumRR[4],
       a1, a2, a3, dr, ee, sumXY, sumYZ, sumZX, t;
    int i, j, k, n, n1;
    countChainProps = countChainProps + 1;
    if (countChainProps == 1) aaDistSq = eeDistSq = 
       radGyrSq = gMomRatio1 = gMomRatio2 = 0.;
    n = 0;
    for (i = 1; i <= nChain; i ++) {
      ee = sumXY = sumYZ = sumZX = 0.;
      for (k = 1; k <= NDIM; k ++) shift[k] = sumR[k] = sumRR[k] = 0.;
      for (j = 1; j <= chainLen; j ++) {
        n = n + 1;
        if (j > 1) {
          for (k = 1; k <= 3; k ++) {
            dr = r[k][n] - r[k][n - 1];
            if (fabs (dr) > regionH[k]) {
              t = SignR (region[k], dr);
              shift[k] = shift[k] - t;    dr = dr - t;
            }
            aaDistSq = aaDistSq + Sqr (dr);
          }
        } else n1 = n;
        for (k = 1; k <= 3; k ++) {
          c[k] = r[k][n] + shift[k];
          sumR[k] = sumR[k] + c[k]; 
          sumRR[k] = sumRR[k] + Sqr (c[k]);
        }
        sumXY = sumXY + c[1] * c[2];
        sumYZ = sumYZ + c[2] * c[3];
        sumZX = sumZX + c[3] * c[1];
      }
      for (k = 1; k <= 3; k ++) {
        ee = ee + Sqr (c[k] - r[k][n1]);
        sumR[k] = sumR[k] / chainLen;
        g[k] = sumRR[k] / chainLen - sumR[k] * sumR[k];
      }
      eeDistSq = eeDistSq + ee;
      g[4] = sumXY / chainLen - sumR[1] * sumR[2];
      g[5] = sumZX / chainLen - sumR[3] * sumR[1];
      g[6] = sumYZ / chainLen - sumR[2] * sumR[3];
      a1 = - g[1] - g[2] - g[3];
      a2 = g[1] * g[2] + g[2] * g[3] + g[3] * g[1] - 
         Sqr (g[4]) - Sqr (g[5]) - Sqr (g[6]);
      a3 = g[1] * Sqr (g[6]) + g[2] * Sqr (g[5]) + g[3] * Sqr (g[4]) -
         2. * g[4] * g[5] * g[6] - g[1] * g[2] * g[3];
      SolveCubic (a1, a2, a3, g);
      gVal[1] = Max3R (g[1], g[2], g[3]);
      gVal[3] = Min3R (g[1], g[2], g[3]);
      gVal[2] = g[1] + g[2] + g[3] - gVal[1] - gVal[3];
      radGyrSq = radGyrSq + gVal[1] + gVal[2] + gVal[3];
      gMomRatio1 = gMomRatio1 + gVal[2] / gVal[1];
      gMomRatio2 = gMomRatio2 + gVal[3] / gVal[1];
    }
    if (countChainProps == limitChainProps) {
      aaDistSq = aaDistSq  / (nChain * (chainLen - 1) * limitChainProps);
      eeDistSq = eeDistSq / (nChain * limitChainProps);
      radGyrSq = radGyrSq / (nChain * limitChainProps);
      gMomRatio1 = gMomRatio1 / (nChain * limitChainProps);
      gMomRatio2 = gMomRatio2 / (nChain * limitChainProps);
      PrintChainProps (stdout);
      countChainProps = 0;
    }
  }
  
  SolveCubic (real a1, real a2, real a3, real *g) {
    real q1, q2, t;
    q1 = sqrt (a1 * a1 - 3. * a2) / 3.;
    q2 = (2. * a1 * a1 * a1 - 9. * a1 * a2 + 27. * a3) / 54.;
    t = acos (q2 / (q1 * q1 * q1));
    g[1] = - 2. * q1 * cos (t / 3.) - a1 / 3.;
    g[2] = - 2. * q1 * cos ((t + 2. * pi) / 3.) - a1 / 3.;
    g[3] = - 2. * q1 * cos ((t + 4. * pi) / 3.) - a1 / 3.;
  }
  
  PrintChainProps (FILE *fp)
  {
    fprintf (fp, "chain props: %5d %8.4f %.3f %.3f %.3f %.3f %.3f\n",
       stepCount,timeNow,sqrt (aaDistSq), eeDistSq, radGyrSq, gMomRatio1, gMomRatio2);
  }

