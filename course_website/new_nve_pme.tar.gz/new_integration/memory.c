#include "build.h"

void memory(char *text)
{

   printf("Checkpoint %s:", text);
   fflush(NULL);
   system("ps -o rssize,comm | grep simu ");
   printf("\n");
   fflush(NULL);

}
