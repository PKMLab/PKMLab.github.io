void init_stress_prof(int n_slabs, int n_blocks, double **p_normal_vdw, double **p_tangent_vdw,
                double ***p_normal_vdw_block, double ***p_tangent_vdw_block, double **p_normal_coul,
                double **p_tangent_coul, double ***p_normal_coul_block, double ***p_tangent_coul_block,
                double **p_normal, double **p_tangent, double ***p_normal_block, double ***p_tangent_block,
                double **dens_prof, double ***dens_prof_block, double **ift_block,
                double **p_tangent_stretch, double **p_normal_stretch, double **p_tangent_bend,
                double **p_normal_bend, double ***dens_prof_species, double ****dens_prof_species_block,
                int n_species);

void profiles(int n_bins, int n_atoms, double **scaled_atom_coords, int n_species, 
		 double **h, double *dens_prof,
              int *atom_mol, int *mol_species, double **dens_prof_species);

void surface_tension_block(int i_block, int n_slab, double *p_normal, double *p_tangent,
                           double *dens_prof, double **p_nromal_block, double **p_tangent_block,
                           double **dens_prof_block, double **dens_prof_species,
                           double ***dens_prof_species_block, int n_species);
void write_tension_block(int i_block, int n_block, int n_slab, double **p_normal_block,
                         double **p_tangent_block, double **dens_prof_block,
                         double **h_block, double *vol_block, double *ift_block, int i_cycle, 
                         double temp, double ***dens_prof_species_block, int n_species);
