/* Shared utilities for molecular modeling package. */

#include "build.h"

/* Error-handling routine. */
void error_exit(char *error_msg)
{
   puts(error_msg);
   exit(1);
}

